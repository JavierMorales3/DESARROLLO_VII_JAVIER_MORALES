CREATE TABLE Notificaciones (
    notificacion_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    mensaje TEXT NOT NULL,
    estado VARCHAR(50) NOT NULL DEFAULT 'no leida' CHECK (estado IN ('leida', 'no leida')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id)
);