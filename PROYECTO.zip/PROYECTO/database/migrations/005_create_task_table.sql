CREATE TABLE Tareas (
    tarea_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    descripcion TEXT,
    fecha_vencimiento DATE,
    is_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    proyecto_id INT NOT NULL,
    encargado_id INT,
    FOREIGN KEY (proyecto_id) REFERENCES proyectos(proyecto_id),
    FOREIGN KEY (encargado_id) REFERENCES usuarios(usuario_id)
);