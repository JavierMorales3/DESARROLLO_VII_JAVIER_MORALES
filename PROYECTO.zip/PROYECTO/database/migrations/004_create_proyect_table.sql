CREATE TABLE Proyectos (
    proyecto_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nombre_proyecto VARCHAR(255) NOT NULL,
    descripcion TEXT,
    fecha_inicio TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_finalizacion DATE,
    estado VARCHAR(50) NOT NULL DEFAULT 'planificado' CHECK (estado IN ('planificado', 'en curso', 'finalizado'))
);