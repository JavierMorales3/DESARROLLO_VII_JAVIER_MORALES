CREATE DATABASE gestion_proyectos_db;

USE gestion_proyectos_db;

CREATE TABLE Usuarios (
    usuario_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    correo_electronico VARCHAR(100) UNIQUE NOT NULL,
    contrasena VAR(100) NOT NULL,
    rol VARCHAR(100)
);