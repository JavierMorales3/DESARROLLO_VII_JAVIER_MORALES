<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<div class="task-form">
    <h2 style="text-align: center;">Redactar Notificacion</h2>
    <form action="?action=create" method="post">

        <h3><div>Titulo</div></h3>
        <input type="text" name="title" required style="width: 80%; padding: 8xp;">

        <h3><div>Mensaje</div></h3>
        <div><textarea name="mensaje" style="width: 80%; height: 150px; padding: 8xp;"></textarea><div>
        
        <div>
            <h3><label for="destinatario">Enviar a:</label></h3>
                <select name="destinatario" id="incharge">
                    <?php foreach ($empleados as $empleado): ?>
                        <option value="<?= $empleado->usuario_id ?>">
                            <?= htmlspecialchars($empleado->nombre)?>
                        </option>
                    <?php endforeach; ?>
                </select>
        </div>

        <button type="submit" class="btn"><h3>Enviar</h3></button>

    </form>
    <br>
    <a href="?action=list" class="btn"><h3>Volver</h3></a>
</div>
<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>