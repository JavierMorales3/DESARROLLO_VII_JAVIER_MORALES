<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/assets/css/style.css">
<div class="task-list">
    <h2 style="text-align: center;">Notificaciones</h2>
    <a href="?action=create" class="btn">Enviar Nueva Notificacion</a>
    <table class="task-table">
        <thead>
            <tr>
                <th>Para</th>
                <th>Titulo</th>
                <th>Mensaje</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($notifications as $notification): ?>
                <tr>
                    <td><?= htmlspecialchars($notification->destinatario) ?></td>
                    <td><?= htmlspecialchars($notification->title) ?></td>
                    <td><?= htmlspecialchars($notification->mensaje) ?></td>
                    <td>
                        <a href="?action=delete&id=<?=  $notification->notificacion_id ?>" class="btn" onclick="return confirm('¿Eliminar Notificacion?')">🗑</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>
<?php 
// Iniciamos el buffer de salida
ob_start();
?>