<?php
class Notification {
    public $notificacion_id;
    public $mensaje;
    public $estado;
    public $destinatario;
    public $title;

    // Constructor para crear un objeto Notification a partir de un array de datos
    public function __construct($data) {
        $this->notificacion_id = $data['notificacion_id'];
        $this->title = $data['title'];
        $this->mensaje = $data['mensaje'];
        $this->estado = $data['estado'];
        $this->destinatario = $data['destinatario'];
    }

    // Aquí podrían añadirse métodos adicionales relacionados con una notificacion individual
}