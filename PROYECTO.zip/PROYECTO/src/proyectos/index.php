<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
#error_reporting(E_ALL);

// Define the base path for includes
define('BASE_PATH', __DIR__ . '/');

// Include the configuration file
require_once BASE_PATH . '../../config.php';

// Include necessary files
require_once BASE_PATH . '../Database.php';
require_once BASE_PATH . 'ProyectManager.php';
require_once BASE_PATH . 'Proyect.php';

// Create an instance of ProyectManager
$ProyectManager = new ProyectManager();

// Get the action from the URL, default to 'list' if not set
$action = $_GET['action'] ?? 'list';

//Si se proporciona el estado que se quiere listar la vista de proyectos
$estado_filtro = $_GET['estado'] ?? null;

// Handle different actions
switch ($action) {
        case 'create':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $proyect = new Proyect($_POST);
                $ProyectManager->createProyects($proyect);
                header('Location: ' . BASE_URL . '/proyectos');
                exit;
            }
            require BASE_PATH . 'views/proyect_form.php';
            break;

        case 'edit':
            $ProyectManager->editProyects($_GET['id'], $_GET['estado']);
            header('Location: ' . BASE_URL . '/proyectos');
            break;

        case 'delete':
            $ProyectManager->deleteProyects($_GET['id']);
            header('Location: ' . BASE_URL . '/proyectos');
            break;

        case 'gant':
            $proyectos = $ProyectManager->getAllProjects();
            require BASE_PATH . 'views/gantt.php';
            break;

        default:
            if ($estado_filtro) {
                $proyectos = $ProyectManager->toggleProyect($_GET['estado']);
            } else {
                $proyectos = $ProyectManager->getAllProjects();
            }
            require BASE_PATH . 'views/list.php';
            break;
}