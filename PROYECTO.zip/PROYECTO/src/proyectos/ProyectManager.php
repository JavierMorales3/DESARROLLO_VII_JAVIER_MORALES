<?php
class ProyectManager {
    private $db;

    public function __construct() {
        // Obtenemos la conexión a la base de datos
        $this->db = Database::getInstance()->getConnection();
    }

    // Método para obtener todas los proyectos
    public function getAllProjects() {
        $stmt = $this->db->query("SELECT p.*, COUNT(t.tarea_id) AS total_tareas, COALESCE(SUM(CASE WHEN t.is_completed = 1 THEN 1 ELSE 0 END), 0) AS tareas_completadas FROM Proyectos p LEFT JOIN Tareas t ON p.proyecto_id = t.proyecto_id GROUP BY p.proyecto_id ORDER BY fecha_inicio DESC");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $map = array_map(function ($item) { 
            $proyect = new Proyect($item); 
            $proyect->total_tareas = $item['total_tareas'];
            $proyect->tareas_completadas = $item['tareas_completadas'];
            return $proyect; 
        }, $data);
        return $map;
    }

    // Método para crear un nuevo proyecto
    public function createProyects($proyect) {
        $stmt = $this->db->prepare("INSERT INTO Proyectos (nombre_proyecto, descripcion, fecha_finalizacion) VALUES (?,?,?)");
        $payload = [ $proyect->nombre_proyecto, $proyect->descripcion, $proyect->fecha_finalizacion];
        return $stmt->execute($payload);
    }

    // Método para filtrar vista de un proyecto (planificado/en proceso/completado)
    public function toggleProyect($estado) {
        if (empty($estado)) {
           return [];
        }
        $stmt = $this->db->prepare("SELECT p.*, COUNT(t.tarea_id) AS total_tareas, COALESCE(SUM(CASE WHEN t.is_completed = 1 THEN 1 ELSE 0 END), 0) AS tareas_completadas FROM Proyectos p LEFT JOIN Tareas t ON p.proyecto_id = t.proyecto_id WHERE estado = ? GROUP BY p.proyecto_id ORDER BY p.fecha_inicio DESC");
        $stmt->execute([$estado]);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $map = array_map(function ($item) { return new Proyect($item); }, $data);
        return $map;
    }

    // Método para editar estado de un proyecto
    public function editProyects($proyecto_id, $estado) {
        $stmt = $this->db->prepare("UPDATE Proyectos set estado = ? WHERE proyecto_id = ?");
        return $stmt->execute([$estado, $proyecto_id]);
    }


    // Método para eliminar un proyecto
    public function deleteProyects($proyecto_id) {
        $stmt = $this->db->prepare("DELETE FROM Proyectos WHERE proyecto_id = ?");
        return $stmt->execute([$proyecto_id]);
    }
}