<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<div class="proyect-form">
    <h2 style="text-align: center;">Creacion de Proyecto</h2>
    <form action="?action=create" method="post">

        <div>Titulo</div>
        <input type="text" name="nombre_proyecto" required style="width: 80%; padding: 8xp;">

        <div>Descripcion</div>
        <div><textarea name="descripcion" required style="width: 80%; height: 150px; padding: 8xp;"></textarea><div>
        
        <div>
            <h3><label for="fecha_finalizacion">Fecha Limite:</label></h3>
            <input type="date" name="fecha_finalizacion" id="fecha_finalizacion" min="<?= date('Y-m-d', strtotime('+1 day'))?>" required>
        </div>
        
        <button type="submit" class="btn"><h3>Confirmar</h3></button>

    </form>
    <br>

    <a href="?action=list" class="btn"><h3>Volver</h3></a>

</div>
<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>