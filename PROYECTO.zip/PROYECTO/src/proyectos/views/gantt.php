<?php 
// Iniciamos el buffer de salida
ob_start(); 

$ganttTasks = [];

    if(!empty($proyectos)) {
        foreach ($proyectos as $proyect) {
            if(!empty($proyect->fecha_finalizacion)) {
                $fechaInicio = date('Y-m-d', strtotime($proyect->fecha_inicio));
                $fechaFin = date('Y-m-d', strtotime($proyect->fecha_finalizacion));


                $ganttTasks[] = [
                    "id" => $proyect->proyecto_id,
                    "name" => $proyect->nombre_proyecto,
                    "start" => $fechaInicio,
                    "end" => $fechaFin
                ]; 
            }
        }
    }
?> 

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Hyper</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Proyectos</a></li>
                                            <li class="breadcrumb-item active">Gantt</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Gantt</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <!-- start projects-->
                                    <div class="col-xxl-3 col-lg-4">
                                        <div class="pe-xl-3">
                                            <h5 class="mt-0 mb-3">Proyectos</h5>
                                        </div>

                                        <div class="row">
                                            <?php foreach ($proyectos as $proyect): ?> 
                                                <div class="col-12">
                                                    <div class="pe-xl-3" data-simplebar style="max-height: 535px;">
                                                        <a href="javascript:void(0);" class="text-body">
                                                            <div class="d-flex mt-2 p-2">
                                                                <div class="avatar-sm d-table">
                                                                    <span class="avatar-title bg-success-lighten rounded-circle text-success">
                                                                        <i class='uil uil-moonset font-24'></i>
                                                                    </span>
                                                                </div>
                                                                <div class="ms-2">
                                                                    <h5 class="mt-0 mb-0">
                                                                        <span class="badge badge-success-lighten ms-1"><?= htmlspecialchars($proyect->estado) ?></span>
                                                                    </h5>
                                                                    <p class="mt-1 mb-0 text-muted">
                                                                        <?= htmlspecialchars($proyect->nombre_proyecto) ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <!-- end projects -->

                                    <!-- gantt view -->
                                    <div class="col-xxl-9 mt-4 mt-xl-0 col-lg-8">
                                        <div class="ps-xl-3">
                                            <div class="row">
                                                <div class="col mt-3">
                                                    <svg id="tasks-gantt"></svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end gantt view -->
                                </div>
                            </div>
                        </div>

                    </div> <!-- container -->

            

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        <!-- gantt js-->
        <script>
            document.addEventListener('DOMContentLoaded', function () {

                const ganttTasks = <?= json_encode($ganttTasks, JSON_UNESCAPED_UNICODE)?>;
                const ganttSvg = document.querySelector('#tasks-gantt');

                if(!ganttSvg) return;

                if(ganttTasks.length > 0) {
                    new Gantt(ganttSvg, ganttTasks, {
                        view_mode: "Day",
                        date_format: "YYYY-MM-DD",
                        custom_popup_html: function(task) {
                                return `
                                <div class="details-container p-2"> 
                                    <h5>${task.name}</h5> 
                                    <p><strong>Fecha de vencimiento:</strong> ${task.end}</p> 
                                </div>
                            `;
                        }
                    });    
                } else  {
                    ganttSvg.style.display = 'none';

                    ganttSvg.insertAdjacentHTML(
                        'beforebegin',
                        '<p class="text-muted mt-2">No hay proyectos con fecha de vencimiento para mostrar.</p>'
                    );
                }

            });

        </script>

 


<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>

