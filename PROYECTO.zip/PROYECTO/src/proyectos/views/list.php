<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<!-- Start Content-->
<div class="container-fluid">
    
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">TechCastro</a></li>
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Proyectos</a></li>
                        <li class="breadcrumb-item active">Lista de Proyectos</li>
                    </ol>
                </div>
                <h4 class="page-title">Lista de Proyectos</h4>
            </div>
        </div>
    </div>
    <!-- end page title --> 

    <div class="row mb-2">
            <div class="col-sm-4 d-flex align-items-start">
                <a href="?action=create" class="btn btn-danger rounded-pill mb-3 me-2"><i class="mdi mdi-plus"></i> Crear Proyecto</a>
                <a href="?action=gant" class="btn btn-danger rounded-pill mb-3">Diagrama Gantt</a>
            </div>



        <div class="col-sm-8">
            <div class="text-sm-end">
                <div class="btn-group mb-3">
                    <a href="?action=list" type="button" class="btn btn-primary">All</a>
                </div>
                <div class="btn-group mb-3 ms-1">
                    <a href="?action=toggle&estado=planificado" type="button" class="btn btn-light">Planificado</a>
                    <a href="?action=toggle&estado=en curso" type="button" class="btn btn-light">En curso</a>
                    <a href="?action=toggle&estado=finalizado" type="button" class="btn btn-light">Finalizado</a>
                </div>
            </div>
        </div><!-- end col-->
    </div> 
    <!-- end row-->

    <div class="row">
        <?php foreach ($proyectos as $proyect): ?> 
            <div class="col-md-6 col-xxl-3">
                <!-- project card -->
                <div class="card d-block">
                    <div class="card-body">
                        <div class="dropdown card-widgets">
                            <a href="#" class="dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="dripicons-dots-3"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!-- item-->
                                <a href="?action=edit&id=<?=  htmlspecialchars($proyect->proyecto_id) ?>&estado=planificado" class="dropdown-item"><i class="mdi mdi-pencil me-1"></i>Planificado</a>
                                <!-- item-->
                                <a href="?action=edit&id=<?=  htmlspecialchars($proyect->proyecto_id) ?>&estado=en curso" class="dropdown-item"><i class="mdi mdi-pencil me-1"></i>En curso</a>
                                <!-- item-->
                                <a href="?action=edit&id=<?=  htmlspecialchars($proyect->proyecto_id) ?>&estado=finalizado" class="dropdown-item"><i class="mdi mdi-pencil me-1"></i>Finalizado</a>
                                <!-- item-->
                                <a href="?action=delete&id=<?=  htmlspecialchars($proyect->proyecto_id) ?>" class="btn" onclick="return confirm('¿Eliminar esta tarea?')">🗑 Eliminar</a>
                            </div>
                        </div>
                        <!-- project title-->
                        <h4 class="mt-0">
                            <a href="apps-projects-details.html" class="text-title"><?= htmlspecialchars($proyect->nombre_proyecto) ?></a>
                        </h4>
                        <div class="badge bg-success"><?= htmlspecialchars($proyect->estado) ?></div>

                        <p class="text-muted font-13 my-3"><?php echo htmlspecialchars($proyect->descripcion ?? ''); ?><br><a href="javascript:void(0);" class="fw-bold text-muted"></a>
                        </p>

                        <!-- project detail-->
                        <p class="mb-1">
                            <span class="pe-2 text-nowrap mb-2 d-inline-block">
                                <i class="mdi mdi-format-list-bulleted-type text-muted"></i>
                                <b><?= htmlspecialchars($proyect->total_tareas) ?></b> Tareas
                            </span>
                        </p>

                        <p class="mb-1">
                            <span class="pe-2 text-nowrap mb-2 d-inline-block">
                                <i class="mdi mdi-format-list-bulleted-type text-muted"></i>
                                <b><?= htmlspecialchars($proyect->tareas_completadas) ?></b> 
                                    de
                                <b><?= htmlspecialchars($proyect->total_tareas) ?></b> Tareas hechas
                            </span>
                        </p>
                    </div> <!-- end card-body-->
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item p-3">
                            <div class="progress progress-sm">
                                <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
                                </div><!-- /.progress-bar -->
                            </div><!-- /.progress -->
                        </li>
                    </ul>
                </div> <!-- end card-->
            </div> <!-- end col -->
        <?php endforeach; ?>
    </div>
    <!-- end row-->

</div> <!-- container -->
<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>