<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/assets/css/style.css">
<div class="task-list">
    <h2 style="text-align: center;">Lista de Tareas</h2>
    <a href="?action=create" class="btn">Nueva Tarea</a>
        <table class="task-table">
        <thead>
            <tr>
                <th>Titulo</th>
                <th>Descripcion</th>
                <th>Proyecto asociado</th>
                <th>Encargado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tasks as $task): ?>
                <tr class="<?= $task['is_completed'] ? 'completed' : '' ?>">
                    <td><?= htmlspecialchars($task['title']) ?></td>
                    <td><?= htmlspecialchars($task['descripcion']) ?></td>
                    <td><?= htmlspecialchars($task['proyecto_nombre'] ?? 'Sin proyecto') ?></td>
                    <td><?= htmlspecialchars($task['encargado_nombre'] ?? 'Sin asignar') ?></td>
                    <td>
                        <a href="?action=toggle&id=<?= $task['tarea_id'] ?>" class="btn">
                            <?= $task['is_completed'] ? '✓' : '○' ?>
                        </a>
                        <a href="?action=delete&id=<?=  $task['tarea_id'] ?>" class="btn" onclick="return confirm('¿Eliminar esta tarea?')">🗑</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>
<?php 
// Iniciamos el buffer de salida
ob_start();
?>