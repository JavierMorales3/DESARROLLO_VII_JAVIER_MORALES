<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<div class="task-form">
    <h2 style="text-align: center;">Creacion de Tarea</h2>
    <form action="?action=create" method="post">

        <h3><div>Titulo</div></h3>
        <input type="text" name="title" required style="width: 80%; padding: 8xp;">

        <h3><div>Descripcion</div></h3>
        <div><textarea name="descripcion" style="width: 80%; height: 150px; padding: 8xp;"></textarea><div>
        
        <div>
            <h3><label for="encargado">Asignar Encargado:</label></h3>
                <select name="encargado" id="incharge">
                    <?php foreach ($empleados as $empleado): ?>
                        <option value="<?= $empleado->usuario_id ?>">
                            <?= htmlspecialchars($empleado->nombre)?>
                        </option>
                    <?php endforeach; ?>
                </select>
        </div>
        
        <div>
            <h3><label for="proyecto_id">Proyecto Asociado:</label></h3>
                <select name="proyecto_id" id="inproyect">
                    <?php foreach ($proyectos as $proyecto): ?>
                        <option value="<?= $proyecto->proyecto_id ?>">
                            <?= htmlspecialchars($proyecto->nombre_proyecto)?>
                        </option>
                    <?php endforeach; ?>
                </select>
        </div>

        <div>
            <h3><label for="fecha_limite">Fecha Limite:</label></h3>
            <input type="date" name="fecha_exp" id="fecha_expira" min="<?= date('Y-m-d', strtotime('+1 day'))?>" required>
        </div>

        <button type="submit" class="btn"><h3>Confirmar</h3></button>

    </form>
    <br>
    <a href="?action=list" class="btn"><h3>Volver</h3></a>
</div>
<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>