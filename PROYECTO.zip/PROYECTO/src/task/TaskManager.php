<?php
class TaskManager {
    private $db;

    public function __construct() {
        // Obtenemos la conexión a la base de datos
        $this->db = Database::getInstance()->getConnection();
    }

    // Método para obtener todas las tareas
    public function getAllTasks() {
        $stmt = $this->db->query("SELECT t.tarea_id, t.title, t.descripcion, t.is_completed, u.nombre As encargado_nombre, p.nombre_proyecto As proyecto_nombre FROM tareas t LEFT JOIN Usuarios u ON t.encargado_id = u.usuario_id LEFT JOIN Proyectos p ON t.proyecto_id = p.proyecto_id ORDER BY t.tarea_id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para crear una nueva tarea
    public function createTask($task) {
        $stmt = $this->db->prepare("INSERT INTO Tareas (title, descripcion, fecha_vencimiento, proyecto_id, encargado_id ) VALUES (?,?,?,?,?)");
        $payload = [ $task->title, $task->descripcion, $task->fecha_exp, $task->proyecto_id, $task->encargado];
        return $stmt->execute($payload);
    }

    // Método para cambiar el estado de una tarea (completada/no completada)
    public function toggleTask($tarea_id) {
        $stmt = $this->db->prepare("UPDATE Tareas SET is_completed = NOT is_completed WHERE tarea_id = ?");
        return $stmt->execute([$tarea_id]);
    }

    // Método para eliminar una tarea
    public function deleteTask($tarea_id) {
        $stmt = $this->db->prepare("DELETE FROM Tareas WHERE tarea_id = ?");
        return $stmt->execute([$tarea_id]);
    }
}