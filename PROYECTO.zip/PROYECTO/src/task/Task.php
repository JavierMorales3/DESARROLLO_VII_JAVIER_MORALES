<?php
class Task {
    public $tarea_id;
    public $title;
    public $descripcion;
    public $isCompleted;
    public $createdAt;
    public $fecha_exp;
    public $proyecto_id;
    public $encargado;

    // Constructor para crear un objeto Task a partir de un array de datos
    public function __construct($data) {
        $this->tarea_id = $data['tarea_id'];
        $this->title = $data['title'];
        $this->descripcion = $data['descripcion'];
        $this->isCompleted = $data['is_completed'];
        $this->createdAt = $data['created_at'];
        $this->fecha_exp = $data['fecha_exp'];
        $this->proyecto_id = $data['proyecto_id'];
        $this->encargado = $data['encargado'];
    }

    // Aquí podrían añadirse métodos adicionales relacionados con una tarea individual
}