<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<div class="task-form">
    <h2 style="text-align: center;">Creacion de Usuario</h2>
    <form action="?action=create" method="post">

        <h3><div>Nombre:</div></h3>
        <input type="text" name="nombre" id=nom_user required style="width: 30%; padding: 8xp;">

        <h3><div>Correo Electrónico:</div></h3>
        <input type="email" name="correo_electronico" id=email_user required style="width: 30%; padding: 8xp;">

        <div>
            <h3><label for="rol">Asignar rol:</label></h3>
                <select name="rol" id="role_user">
                        <option value="" disabled select>Selecciona uno</option>
                        <option value="adminstrador">Adminstrador</option>
                        <option value="empleado">Empleado</option>
                </select>
        </div>
        
        <h3><div>Contraseña:</div></h3>
        <input type="password" name="contrasena" id=contrasena_user required style="width: 30%; padding: 8xp;">

        <div><button type="submit" class="btn"><h3>Confirmar</h3></button></div>

    </form>
    <br>
    <a href="?action=list" class="btn"><h3>Volver</h3></a>
</div>
<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>