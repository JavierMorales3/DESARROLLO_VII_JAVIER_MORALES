<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/assets/css/style.css">
<div class="task-list">
    <h2 style="text-align: center;">Lista de Usuarios</h2>
    <a href="?action=create" class="btn">Nueva Usuario</a>
    <table class="task-table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo Electronico</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $usuario): ?>
                <tr>
                    <td><?= htmlspecialchars($usuario->nombre) ?></td>
                    <td><?= htmlspecialchars($usuario->correo_electronico) ?></td>
                    <td><?= htmlspecialchars($usuario->contrasena) ?></td>
                    <td><?= htmlspecialchars($usuario->rol) ?></td>
                    <td>
                        <a href="?action=delete&id=<?=  $usuario->usuario_id ?>" class="btn" onclick="return confirm('¿Eliminar usuario?')">🗑</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>
<?php 
// Iniciamos el buffer de salida
ob_start();
?>