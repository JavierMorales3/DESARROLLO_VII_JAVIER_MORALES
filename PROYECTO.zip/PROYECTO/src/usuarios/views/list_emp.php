<?php 
// Iniciamos el buffer de salida
ob_start(); 
?>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/assets/css/style.css">
<div class="task-list">
    <h2 style="text-align: center;">Lista de Usuarios</h2>
    <table class="task-table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Rol</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $usuario): ?>
                <tr>
                    <td><?= htmlspecialchars($usuario->nombre) ?></td>
                    <td><?= htmlspecialchars($usuario->rol) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
// Guardamos el contenido del buffer en la variable $content
$content = ob_get_clean();
// Incluimos el layout
require '../../views/layout.php';
?>
<?php 
// Iniciamos el buffer de salida
ob_start();
?>