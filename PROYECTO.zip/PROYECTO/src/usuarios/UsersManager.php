<?php
class UserManager {
    private $db;

    public function __construct() {
        // Obtenemos la conexión a la base de datos
        $this->db = Database::getInstance()->getConnection();
    }

    // Método para obtener todas los usuarios
    public function getAllUsers() {
        $stmt = $this->db->query("SELECT * FROM Usuarios ORDER BY usuario_id ASC");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $map= array_map(function ($item) { return new Users($item);},$data);
        return $map;
    }

    // Método para crear un nuevo usuario
    public function createUser($user) {
        $stmt = $this->db->prepare("INSERT INTO Usuarios (nombre, contrasena, correo_electronico, rol) VALUES (?,?,?,?)");
        $payload = [ $user->nombre, $user->contrasena, $user->correo_electronico, $user->rol];
        return $stmt->execute($payload);
    }

    // Método para cambiar password
    public function editPass($correo_electronico, $contrasena) {
        $stmt = $this->db->prepare("UPDATE Usuarios set contrasena = ? WHERE correo_electronico = ?");
        return $stmt->execute([$contrasena, $correo_electronico]);
    }

    // Método para eliminar un usuario
    public function deleteUser($usuario_id) {
        $stmt = $this->db->prepare("DELETE FROM Usuarios WHERE usuario_id = ?");
        return $stmt->execute([$usuario_id]);
    }

    // Método para traer un usuario en base a su correo
    public function getUserByEmail($correo_electronico) {
        $stmt = $this->db->prepare("SELECT * FROM Usuarios WHERE correo_electronico = ?");
        if ($stmt->execute([$correo_electronico])) {
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($data) {
                return New Users($data);
            }
        }
        return null;
    }

    // Método para traer el rol del usuario en base a su correo
    public function getRoleByUser($correo_electronico) {
        $stmt = $this->db->prepare("SELECT rol FROM Usuarios WHERE correo_electronico = ?");
        if ($stmt->execute([$correo_electronico])) {
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($data) {
                return New Users($data);
            }
        }
        return null;
    }

}