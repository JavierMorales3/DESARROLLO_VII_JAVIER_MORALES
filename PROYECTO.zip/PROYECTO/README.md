Proyecto Final DS7: Sistema de Gestion de Proyectos Simples

Estduiante: Javier Morales
Cedula: 20-62-7469

Requisitos:

- Creación de proyectos y tareas
- Asignación de responsables
- Seguimiento de progreso
- Sistema de notificaciones
- Diagramas de Gantt básicos

