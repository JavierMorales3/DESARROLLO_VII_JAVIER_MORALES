<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Define the base path for includes
define('BASE_PATH', __DIR__ . '/');

// Include the configuration file
require_once BASE_PATH . 'config.php';
require_once BASE_PATH . 'config_sesion.php';

// Include necessary files
require_once BASE_PATH . 'src/Database.php';

require_once BASE_PATH . '/src/usuarios/UsersManager.php';
require_once BASE_PATH . '/src/usuarios/Users.php';

// Get the action from the URL, default to null if not set
$action = $_GET['action'] ?? null;

// Handle different actions
switch ($action) {

    case 'log':

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $correo = $_POST['correo_electronico'];
                $clave = $_POST['contrasena'];
                $usersManager = new UserManager();
                $user = $usersManager->getUserByEmail($correo);

                if($user && $clave === $user->contrasena) {
                    $_SESSION['usuario_id'] = $user->usuario_id;
                    $_SESSION['usuario'] = $user->nombre;
                    $_SESSION['rol'] = $user->rol;

                    $_SESSION['ultima_actividad'] = time();

                    if($user->rol === "administrador") {
                        header('Location: ' . BASE_URL . "/views/dashboard.php");
                        exit;
                    } 
                    
                    if($user->rol === "empleado") {
                        header('Location: ' . BASE_URL . "/views/dashboard_emp.php");
                        exit;
                    }

                } else {
                    $error = "Correo o contraseña incorrectos";
                } 

            }       
            break;

    case 'edit':
        header('Location: ' . BASE_URL . "/views/pass_edit.php");
        exit();

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8" />
        <title>Log In | TechCastro</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo BASE_URL; ?>assets/images/favicon.ico">
        
        <!-- App css -->
        <link href="<?php echo BASE_URL; ?>/views/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo BASE_URL; ?>/views/assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style"/>

</head>
    
    <body class="loading authentication-bg" data-layout-config='{"darkMode":false}'>
        <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xxl-4 col-lg-5">
                        <div class="card">

                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <h4 class="text-dark-50 text-center pb-0 fw-bold">Sign In</h4>
                                </div>

                                <?php if (!empty($error)): ?>
                                    <div class= "alert alert-danger text-center">
                                        <?= $error ?>
                                    </div>
                                <?php endif; ?>

                                <form action="?action=log" method="post">

                                    <div class="mb-3">
                                        <label for="correo_electronico" name="correo_electronico" class="form-label">Correo Electrónico</label>
                                        <input class="form-control" type="email" name= "correo_electronico" id="correo_electronico" required>
                                    </div>

                                    <div class="mb-3">
                                        <a href="?action=edit" class="text-muted float-end"><small>Olvidaste tu contraseña?</small></a>
                                        <label for="contrasena" name="contrasena" class="form-label">Contraseña</label>
                                        <div class="input-group input-group-merge">
                                            <input type="password" id="contrasena" name="contrasena" class="form-control" required>
                                        </div>
                                    </div>

                                    <div class="mb-3 mb-0 text-center">
                                        <button class="btn btn-primary" type="submit"> Log In </button>
                                    </div>

                                </form>
                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->

        <footer class="footer footer-alt">
            2018 - <script>document.write(new Date().getFullYear())</script> © Hyper - Coderthemes.com
        </footer>

        <!-- bundle -->
        <script src="<?php echo BASE_URL; ?>/views/assets/js/vendor.min.js"></script>
        <script src="<?php echo BASE_URL; ?>/views/assets/js/app.min.js"></script>
        
    </body>

</html>
