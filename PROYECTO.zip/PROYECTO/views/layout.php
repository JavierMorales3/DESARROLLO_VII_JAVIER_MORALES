<?php 
// Incluimos la cookies y configuracion
require_once __DIR__ . '/../config_sesion.php';
$nomb = $_SESSION['usuario'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from coderthemes.com/hyper/saas/dashboard-projects.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 29 Jul 2022 10:20:35 GMT -->
<head>
        <meta charset="utf-8" />
        <title>Gestion Proyectos Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo BASE_URL; ?>/views/assets/images/favicon.ico">

        <!-- App css -->
        <link href="<?php echo BASE_URL; ?>/views/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo BASE_URL; ?>/views/assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style"/>
        <link href="<?php echo BASE_URL; ?>/views/assets/css/vendor/frappe-gantt.css" rel="stylesheet" type="text/css" />
        <!-- third party css end -->


    </head>

    <body class="loading" data-layout-color="light" data-leftbar-theme="dark" data-layout-mode="fluid" data-rightbar-onstart="true">
        <!-- Begin page -->
        <div class="wrapper">

            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">
    
                <!-- LOGO -->
                <a href="index.html" class="logo text-center logo-light">
                    <span class="logo-lg">
                        <img src="<?php echo BASE_URL; ?>/views/assets/images/logo.png" alt="" height="16">
                    </span>
                    <span class="logo-sm">
                        <img src="<?php echo BASE_URL; ?>/views/assets/images/logo_sm.png" alt="" height="16">
                    </span>
                </a>

                <!-- LOGO -->
                <a href="index.html" class="logo text-center logo-dark">
                    <span class="logo-lg">
                        <img src="<?php echo BASE_URL; ?>/views/assets/images/logo-dark.png" alt="" height="16">
                    </span>
                    <span class="logo-sm">
                        <img src="<?php echo BASE_URL; ?>/views/assets/images/logo_sm_dark.png" alt="" height="16">
                    </span>
                </a>
    
                <div class="h-100" id="leftside-menu-container" data-simplebar>

                    <!--- Sidemenu -->
                    <ul class="side-nav">

                        <li class="side-nav-title side-nav-item">Navegacion</li>

						<li class="side-nav-item">
                            <a href="<?php echo BASE_URL; ?>/views/dashboard.php" class="side-nav-link">
                                <i class="uil-home-alt"></i>
                                <span> Dashboard </span>
                            </a>
                        </li>                    


						
                        <li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#sidebarProjects" aria-expanded="false" aria-controls="sidebarProjects" class="side-nav-link">
                                <i class="uil-briefcase"></i>
                                <span> Proyectos </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="sidebarProjects">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="<?php echo BASE_URL; ?>/proyectos/">List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>		

						<li class="side-nav-item">
                            <a data-bs-toggle="collapse" href="#sidebarTasks" aria-expanded="false" aria-controls="sidebarTasks" class="side-nav-link">
                                <i class="uil-clipboard-alt"></i>
                                <span> Tareas </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="sidebarTasks">
                                <ul class="side-nav-second-level">
                                    <li>
                                        <a href="<?php echo BASE_URL; ?>/task/">List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        
						<li class="side-nav-item">
                            <a href="<?php echo BASE_URL; ?>/usuarios/" class="side-nav-link">
                                <i class="mdi mdi-account-circle me-1"></i>
                                <span> Registro Usuarios </span>
                            </a>
                        </li> 

                    </ul>

                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Topbar Start -->
                    <div class="navbar-custom">
                        <ul class="list-unstyled topbar-menu float-end mb-0">

                            <li class="dropdown notification-list">
                                <a href="<?php echo BASE_URL; ?>/notificacion/">
                                    <i class="dripicons-bell noti-icon"></i>
                                </a>
                            </li>


                            <li class="dropdown notification-list">
                                <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false"
                                    aria-expanded="false">
                                    <span class="account-user-avatar"> 
                                        <img src="<?php echo BASE_URL; ?>/views/assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle">
                                    </span>
                                    <span>
                                        <span class="account-user-name">
                                            <?php $nomb; ?>
                                            <?= htmlspecialchars($_SESSION['usuario'] ?? 'Invitado')?>
                                        </span>

                                        <span class="account-position">
                                            <?= htmlspecialchars($_SESSION['rol'] ?? 'Regular')?>
                                        </span>
                                    </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                    <!-- item-->
                                    <a href="<?php echo BASE_URL; ?>/views/cerrar_sesion.php" class="dropdown-item notify-item">
                                        <i class="mdi mdi-logout me-1"></i>
                                        <span>Logout</span>
                                    </a>
                                </div>
                            </li>

                        </ul>
                        <button class="button-menu-mobile open-left">
                            <i class="mdi mdi-menu"></i>
                        </button>
                        
                    </div>
                    <!-- end Topbar -->

                    <?php echo $content; ?>
                </div> <!-- content -->

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © TechCastro
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->

        <!-- bundle -->
        <script src="<?php echo BASE_URL; ?>/views/assets/js/vendor.min.js"></script>
        <script src="<?php echo BASE_URL; ?>/views/assets/js/app.min.js"></script>
        <script src="<?php echo BASE_URL; ?>/views/assets/js/vendor/frappe-gantt.min.js"></script>

        <!-- third party js -->
        <script src="<?php echo BASE_URL; ?>/views/assets/js/vendor/chart.min.js"></script>
        <!-- third party js ends -->

        <!-- demo app -->
        <script src="<?php echo BASE_URL; ?>/views/assets/js/pages/demo.dashboard-projects.js"></script>
        <!-- end demo js-->

    </body>


<!-- Mirrored from coderthemes.com/hyper/saas/dashboard-projects.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 29 Jul 2022 10:20:36 GMT -->
</html>
