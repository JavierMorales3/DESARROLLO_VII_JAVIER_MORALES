<?php
// Define the base path for includes
define('BASE_PATH', __DIR__ . '/');
// Include the configuration file
require_once BASE_PATH . '../config_sesion.php';

$_SESSION = array();
session_destroy();
header('Location: ' . BASE_URL);
exit();
?>